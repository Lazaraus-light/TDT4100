package oving5.Named;

public interface Named {
    void setGivenName(String givenName);
    String getGivenName();

    void setFamilyName(String familyName);
    String getFamilyName();

    void setFullName(String fullName);
    String getFullName();
}
