package oving5.Ticket;

public interface Ticket {
    boolean scan();
}
